from django.urls import path
from .views import login_page , signup_page ,homepage, colorize_image

urlpatterns = [
    path('signup/', signup_page, name='signup'),
    path('', login_page, name='login'),
    path('home/', homepage, name='homepage'),
    path('colorize/', colorize_image, name='colorize_image'),
]