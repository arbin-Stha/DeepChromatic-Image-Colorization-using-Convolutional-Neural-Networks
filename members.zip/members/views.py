import os
import numpy as np
import cv2
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.http import JsonResponse
from django.core.files.storage import default_storage
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import logging


logger = logging.getLogger(__name__)

MODEL = os.path.join(settings.BASE_DIR, 'models/custom_cnn_model.h5')
PROTOTXT = os.path.join(settings.BASE_DIR, 'models/colorization_deploy_v2.prototxt')
POINTS = os.path.join(settings.BASE_DIR, 'models/pts_in_hull.npy')
MODEL = os.path.join(settings.BASE_DIR, 'models/CNN_models')


print("Load model")
net = cv2.dnn.readNetFromCaffe(PROTOTXT, MODEL)
pts = np.load(POINTS)


class8 = net.getLayerId("class8_ab")
conv8 = net.getLayerId("conv8_313_rh")
pts = pts.transpose().reshape(2, 313, 1, 1)
net.getLayer(class8).blobs = [pts.astype("float32")]
net.getLayer(conv8).blobs = [np.full([1, 313], 2.606, dtype="float32")]

def colorize(image_path):

    image = cv2.imread(image_path)
    scaled = image.astype("float32") / 255.0
    lab = cv2.cvtColor(scaled, cv2.COLOR_BGR2LAB)

    resized = cv2.resize(lab, (224, 224))
    L = cv2.split(resized)[0]
    L -= 50

    print("Colorizing the image")
    net.setInput(cv2.dnn.blobFromImage(L))
    ab = net.forward()[0, :, :, :].transpose((1, 2, 0))

    ab = cv2.resize(ab, (image.shape[1], image.shape[0]))

    L = cv2.split(lab)[0]
    colorized = np.concatenate((L[:, :, np.newaxis], ab), axis=2)

    colorized = cv2.cvtColor(colorized, cv2.COLOR_LAB2BGR)
    colorized = np.clip(colorized, 0, 1)

    colorized = (255 * colorized).astype("uint8")

    
    colorized_image_path = image_path.replace('.jpg', '_colorized.jpg')
    cv2.imwrite(colorized_image_path, colorized)
    return colorized_image_path

@csrf_exempt
def colorize_image(request):
    if request.method == 'POST':
        uploaded_image = request.FILES.get('image')
        if uploaded_image:
            try:
                
                image_name = uploaded_image.name
                image_path = default_storage.save(image_name, uploaded_image)
                full_image_path = os.path.join(settings.MEDIA_ROOT, image_path)

                
                colorized_image_path = colorize(full_image_path)

                
                colorized_image_url = os.path.join(settings.MEDIA_URL, os.path.basename(colorized_image_path))

                return JsonResponse({'url': colorized_image_url})
            except Exception as e:
                logger.error(f"Error processing image: {e}")
                return JsonResponse({'error': 'Error processing image'}, status=500)
        
    return JsonResponse({'error': 'Invalid request'}, status=400)

def homepage(request):
    return render(request, 'homepage.html')

def signup_page(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        if password == confirm_password:
            User.objects.create_user(username=email, first_name=first_name, last_name=last_name, email=email, password=password)
            return redirect('login')
        else:
            return render(request, 'signup.html', {'error': 'Passwords do not match'})
    return render(request, 'signup.html')

def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('homepage')
    return render(request, 'login.html')
