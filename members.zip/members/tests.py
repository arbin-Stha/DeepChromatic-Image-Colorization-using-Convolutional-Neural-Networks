from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User

class SimpleTest(TestCase):
    def test_homepage_status_code(self):
        # Ensure that the homepage returns a status code 200 (OK)
        response = self.client.get(reverse('homepage'))
        self.assertEqual(response.status_code, 200)

    def test_signup_page(self):
        # Test the signup page for a successful user creation
        response = self.client.post(reverse('signup_page'), {
            'first_name': 'John',
            'last_name': 'Doe',
            'email': 'john@example.com',
            'password': 'password123',
            'confirm_password': 'password123'
        })
        self.assertEqual(response.status_code, 302)  # Redirects after signup
        self.assertTrue(User.objects.filter(username='john@example.com').exists())

    def test_login_page(self):
        # Create a user
        User.objects.create_user(username='jane@example.com', password='password123')
        # Test login
        response = self.client.post(reverse('login_page'), {
            'username': 'jane@example.com',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, 302)  # Redirects after login
